import pandas as pd
import datetime as dt
import time
import calendar
import csv
import matplotlib
import matplotlib.pyplot as plt

from dateutil.relativedelta import relativedelta
from datetime import datetime,timedelta

annee_courant = int(time.strftime("%Y"))
mois_courant = int(time.strftime("%-m"))
semaine_courant  = int(time.strftime("%W"))

fname = fname = "export_donnees_SenseHat.csv" #Nom du fichier CSV dans lequel lire les valeurs

Nb_Jours_Jour = 1 # 1 journée
Nb_Jours_Sem = 7 # Semaine = 7 jours
Nb_Jours_Mois_Courant = calendar.monthrange(int(annee_courant),int(mois_courant))[1] #obtention du nombre de jour dans un mois
Nb_Jours_Annee_Courant = dt.datetime(annee_courant,12,31)- dt.datetime(annee_courant,1,1) # Nombre de jour dans l'année courante
Nb_Jours_Annee_Courant = Nb_Jours_Annee_Courant/timedelta(days=1)



df = pd.read_csv(fname,sep='|',parse_dates=['date'], header=0, names=['date','heure','température 1','température 2','humidité','pression'])
print (df)
                                                      
fig_1 = df.plot(x='date',y='température 1', figsize = (10, 5))

xmin, xmax = plt.xlim() #initialisation des variables xmin, xmax (valeur min/max de l'axe "X") avec la valeur actuel

row_max,column = df.shape #obtention du nombre de ligne et de colonne du csv
row_max = row_max-1 #N° de la ligne max du csv

xmax=df['date'].iloc[row_max] # Valeur de la dernière ligne de la colonne 'date'
xmax = xmax.to_pydatetime() #convertion du timestamp obtenue en date
xmax=xmax.date()#convertion du timestamp obtenue en date

date_min = date_min = df['date'].iloc[0] # Valeur de la première ligne de la colonne date
date_min = date_min.to_pydatetime() #convertion du timestamp obtenue en date
date_min=date_min.date()#convertion du timestamp obtenue en date

#
## Génération des graphs température 1
#

plt.grid()
plt.xlabel('date')
plt.ylabel('température (°C)')
plt.tight_layout()


if xmax-relativedelta(days=Nb_Jours_Jour)<date_min: # Si on a pas le delta de jour d'enregistrement
    print("Evolution sur un jour: il manque malheuresement des valeurs pour afficher toute la plage")
    xmin = date_min
else:
    xmin = xmax - relativedelta(days=Nb_Jours_Jour) # si on a plus que le delta de jour en enregistrement
            
plt.xlim(xmin,xmax) # On "zoom"
plt.savefig("Graphs/temperature_1_Jour.png")  # enregistrement de la courbe

if xmax-relativedelta(days=Nb_Jours_Sem)<date_min: # Si on a pas le delta de jour d'enregistrement
    print("Evolution sur une semaine:il manque malheuresement des valeurs pour afficher toute la plage")
    xmin = date_min
else:
    xmin = xmax - relativedelta(days=Nb_Jours_Sem) # si on a plus que le delta de jour en enregistrement
            
plt.xlim(xmin,xmax) # On "zoom"
plt.savefig("Graphs/temperature_1_Sem.png")  # enregistrement de la courbe

if xmax-relativedelta(days=Nb_Jours_Mois_Courant)<date_min: # Si on a pas le delta de jour d'enregistrement    print("il manque des valeurs pour afficher toute la plage")
    xmin = date_min
    print("Evolution sur un mois:il manque malheuresement des valeurs pour afficher toute la plage")
else:
    xmin = xmax - relativedelta(days=Nb_Jours_Mois_Courant) # si on a plus que le delta de jour en enregistrement
            
plt.xlim(xmin,xmax) # On "zoom"
plt.savefig("Graphs/temperature_1_Mois.png")  # enregistrement de la courbe

if xmax-relativedelta(days=Nb_Jours_Annee_Courant)<date_min: # Si on a pas le delta de jour d'enregistrement
    print("Evolution sur une année:il manque malheuresement des valeurs pour afficher toute la plage")
    xmin = date_min
else:
    xmin = xmax - relativedelta(days=Nb_Jours_Annee_Courant) # si on a plus que le delta de jour en enregistrement
            
plt.xlim(xmin,xmax) # On "zoom"
plt.savefig("Graphs/temperature_1_Annee.png")  # enregistrement de la courbe

#
## Fin Génération des graphs température 1
#

plt._show()